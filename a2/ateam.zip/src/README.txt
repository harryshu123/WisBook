README

COURSE : CS400
SEMESTER : Fall 2019
Project name : Social Network
Team Members :
Chokkarapu Sai Teja, LEC02 , and chokkarapu@wisc.edu
Lintong Han, LEC02, lhan48@wisc.edu
Zhihao Shu, LEC02, zsh9@wisc.edu
Lakshay, LEC02, lgoyal@wisc.edu

Chokkarapu Sai Teja and Lakshay in same xteam.